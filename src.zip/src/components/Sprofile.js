import React from 'react'

export default function Sprofile() {
  return (
    <div>Sprofile</div>
  )
}
