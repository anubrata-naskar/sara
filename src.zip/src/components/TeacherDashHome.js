import React from 'react'

export default function TeacherDashHome() {
  return (
    <div>TeacherDashHome</div>
  )
}
